let historial = [];
let totalCompra = 0;
let fondoOscuro = false; 

function agregarProducto(nombre, precio, idCantidad) {
    const cantidad = parseInt(document.getElementById(idCantidad).value, 10);
    if (cantidad > 0) {
        const subtotal = precio * cantidad;
        historial.push(`${cantidad} x ${nombre} - $${subtotal.toFixed(2)}`);
        totalCompra += subtotal;
        document.getElementById(idCantidad).value = ''; 
        actualizarHistorial();
        actualizarTotal();
    } else {
        alert("Por favor, ingresa una cantidad válida.");
    }
}

function actualizarHistorial() {
    const historialDiv = document.getElementById('historial');
    historialDiv.innerHTML = historial.join('<br>');
}

function actualizarTotal() {
    document.getElementById('total').innerText = totalCompra.toFixed(2);
}

function comprar() {
    if (historial.length === 0) {
        alert("No hay productos en el historial.");
        return;
    }
    alert("Compra realizada con éxito!");
    borrarTodo(); 
}

function borrarSelecciones() {
    document.querySelectorAll('input[type=number]').forEach(input => input.value = ''); 
}

function borrarTodo() {
    historial = [];
    totalCompra = 0;
    document.getElementById('historial').innerHTML = '';
    document.getElementById('total').innerText = '0.00';
    borrarSelecciones(); 
}

function cambiarFondo() {
    fondoOscuro = !fondoOscuro; 
    document.body.style.backgroundColor = fondoOscuro ? '#333' : '#f4f4f4';
    document.body.style.color = fondoOscuro ? '#fff' : '#000';
}